/**
 * 
 */
package com.javateam.service;

import com.javateam.model.vo.PaymentVO;


/**
 * @author ss
 *
 */
public interface PaymentService {
	
	void insertPayment(PaymentVO payment);
	
	PaymentVO getNew();
	PaymentVO get(int paymentNum);
	
}
